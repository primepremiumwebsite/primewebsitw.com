export type Website = {
  id: string;
  title: string;
  category: string;
  description: string;
  price: number;
  image: string;
  tags: string[];
  demoUrl?: string;
};

export const websites: Website[] = [
  {
    id: "2",
    title: "Atelier Studio",
    category: "Agency Portfolio",
    description: "Elegant dark portfolio for creative studios and design agencies.",
    price: 100,
    image: "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?w=1200&q=80",
    tags: ["Animations", "Dark", "Bento"],
  },
  {
    id: "7",
    title: "Burger Express",
    category: "Fast Food",
    description: "Mouth-watering fast food website with online ordering and menu showcase.",
    price: 100,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=1200&q=80",
    tags: ["Menu", "Order", "Delivery"],
  },
  {
    id: "8",
    title: "Bella Pizzeria",
    category: "Pizzeria",
    description: "Authentic pizzeria website with customizable menu and reservations.",
    price: 100,
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=1200&q=80",
    tags: ["Pizza", "Booking", "Menu"],
  },
  {
    id: "9",
    title: "Café Aroma",
    category: "Cafeteria",
    description: "Cozy cafeteria website highlighting coffee, pastries, and ambiance.",
    price: 100,
    image: "https://images.unsplash.com/photo-1501339847302-ac426a4a7cbb?w=1200&q=80",
    tags: ["Coffee", "Menu", "Cozy"],
  },
  {
    id: "5",
    title: "Pulse Fitness",
    category: "Fitness & Coaching",
    description: "Bold landing page for personal trainers and fitness brands.",
    price: 100,
    image: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=1200&q=80",
    tags: ["Bold", "CTA", "Booking"],
  },
  {
    id: "6",
    title: "Maison Real Estate",
    category: "Real Estate",
    description: "Luxurious property listing site with search and detail pages.",
    price: 100,
    image: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200&q=80",
    tags: ["Listings", "Search", "Maps"],
  },
  {
    id: "slot-1",
    title: "Your Website",
    category: "Custom Slot",
    description: "Add your own project here to showcase to your customers.",
    price: 100,
    image: "https://images.unsplash.com/photo-1517842645767-c639042777db?w=1200&q=80",
    tags: ["Custom", "Editable"],
  },
  {
    id: "slot-2",
    title: "Your Website",
    category: "Custom Slot",
    description: "Replace this card with your own work — image, title, price.",
    price: 100,
    image: "https://images.unsplash.com/photo-1559028012-481c04fa702d?w=1200&q=80",
    tags: ["Custom", "Editable"],
  },
  {
    id: "slot-3",
    title: "Your Website",
    category: "Custom Slot",
    description: "Showcase another client project in this editable slot.",
    price: 100,
    image: "https://images.unsplash.com/photo-1545239351-1141bd82e8a6?w=1200&q=80",
    tags: ["Custom", "Editable"],
  },
];
