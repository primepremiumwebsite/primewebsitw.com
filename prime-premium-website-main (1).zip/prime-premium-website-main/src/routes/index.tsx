import { createFileRoute } from "@tanstack/react-router";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { WebsiteGrid } from "@/components/site/WebsiteGrid";

import { Contact } from "@/components/site/Contact";
import { FloatingSocials } from "@/components/site/FloatingSocials";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "Vendora — Premium Websites Marketplace" },
      {
        name: "description",
        content:
          "Buy modern, ready-to-launch websites. Curated templates for SaaS, agencies, e-commerce and more.",
      },
      { property: "og:title", content: "Vendora — Premium Websites Marketplace" },
      {
        property: "og:description",
        content: "Curated, conversion-driven website templates ready to deploy.",
      },
    ],
  }),
});

function Index() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      <WebsiteGrid />
      
      <Contact />
      <FloatingSocials />
    </main>
  );
}
