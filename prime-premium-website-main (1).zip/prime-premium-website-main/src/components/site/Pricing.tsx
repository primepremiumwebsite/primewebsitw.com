const tiers = [
  {
    name: "Starter",
    price: 149,
    desc: "Perfect for personal sites and quick launches.",
    features: ["1 website template", "Source files", "Basic customization", "Email support"],
  },
  {
    name: "Business",
    price: 349,
    desc: "Most popular for startups and small businesses.",
    features: ["Any template", "Custom branding", "Content swap", "Deploy assistance", "Priority support"],
    featured: true,
  },
  {
    name: "Custom",
    price: 899,
    desc: "Bespoke build tailored to your brand.",
    features: ["Custom design", "Unlimited revisions", "Backend integration", "1:1 strategy call", "30-day support"],
  },
];

export function Pricing() {
  return (
    <section id="pricing" className="px-6 py-24">
      <div className="mx-auto max-w-7xl">
        <div className="mb-14 text-center">
          <span className="text-xs font-semibold uppercase tracking-widest text-primary">Pricing</span>
          <h2 className="mt-3 text-4xl font-bold md:text-5xl">Simple, transparent pricing</h2>
          <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
            Pick the plan that fits your stage. Upgrade anytime.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {tiers.map((t) => (
            <div
              key={t.name}
              className={`relative flex flex-col rounded-3xl border p-8 transition-all ${
                t.featured
                  ? "border-primary/50 bg-card-gradient shadow-glow"
                  : "border-border/60 bg-card/40"
              }`}
            >
              {t.featured && (
                <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gradient-to-r from-primary to-accent px-3 py-1 text-xs font-semibold text-primary-foreground">
                  Most popular
                </span>
              )}
              <h3 className="font-display text-2xl font-bold">{t.name}</h3>
              <p className="mt-2 text-sm text-muted-foreground">{t.desc}</p>
              <div className="mt-6 flex items-baseline gap-1">
                <span className="font-display text-5xl font-bold">${t.price}</span>
                <span className="text-sm text-muted-foreground">/ one-time</span>
              </div>
              <ul className="mt-6 flex-1 space-y-3 text-sm">
                {t.features.map((f) => (
                  <li key={f} className="flex items-center gap-2">
                    <span className="grid h-5 w-5 place-items-center rounded-full bg-primary/15 text-primary">✓</span>
                    {f}
                  </li>
                ))}
              </ul>
              <a
                href="#contact"
                className={`mt-8 rounded-full px-5 py-3 text-center text-sm font-semibold transition-transform hover:scale-[1.02] ${
                  t.featured
                    ? "bg-gradient-to-r from-primary to-accent text-primary-foreground"
                    : "bg-foreground text-background"
                }`}
              >
                Get {t.name}
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
