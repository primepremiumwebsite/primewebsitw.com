export function Hero() {
  return (
    <section className="relative overflow-hidden px-6 pt-24 pb-20 md:pt-32 md:pb-28">
      <div className="mx-auto max-w-5xl text-center">
        <span className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-card/40 px-4 py-1.5 text-xs font-medium text-muted-foreground backdrop-blur">
          <span className="h-1.5 w-1.5 rounded-full bg-primary" />
          Premium website marketplace · 2026
        </span>
        <h1 className="mt-6 text-5xl font-bold leading-[1.05] md:text-7xl">
          Prime Premium Website,
          <br />
          <span className="text-gradient-gold">ready to launch.</span>
        </h1>
        <p className="mx-auto mt-6 max-w-2xl text-lg text-muted-foreground">
          Prime premium website ready to launch.
        </p>
        <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
          <a
            href="#websites"
            className="rounded-full bg-gradient-to-r from-primary to-accent px-7 py-3 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-105"
          >
            Browse websites
          </a>
          <a
            href="#contact"
            className="rounded-full border border-border bg-card/40 px-7 py-3 text-sm font-semibold backdrop-blur transition-colors hover:bg-card"
          >
            Request custom build
          </a>
        </div>
        <div className="mx-auto mt-16 grid max-w-3xl grid-cols-3 gap-6 text-center">
          {[
            { k: "10+", v: "Websites built" },
            { k: "3 days", v: "Avg. delivery" },
            { k: "3.8★", v: "Client rating" },
          ].map((s) => (
            <div key={s.v} className="rounded-2xl border border-border/60 bg-card/40 p-5 backdrop-blur">
              <div className="font-display text-3xl font-bold text-gradient-gold">{s.k}</div>
              <div className="mt-1 text-xs uppercase tracking-wider text-muted-foreground">{s.v}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
