import { Link } from "@tanstack/react-router";

export function Navbar() {
  return (
    <header className="sticky top-0 z-50 border-b border-border/40 bg-background/60 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4">
        <Link to="/" className="flex items-center gap-2 font-display text-lg font-bold">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-primary to-accent text-primary-foreground">
            ◆
          </span>
          <span>Prime Premium Website</span>
        </Link>
        <div className="hidden items-center gap-8 text-sm text-muted-foreground md:flex">
          <a href="#websites" className="transition-colors hover:text-foreground">Websites</a>
          <a href="#contact" className="transition-colors hover:text-foreground">Contact</a>
        </div>
        <a
          href="#contact"
          className="rounded-full bg-foreground px-5 py-2 text-sm font-medium text-background transition-transform hover:scale-105"
        >
          Get in touch
        </a>
      </nav>
    </header>
  );
}
