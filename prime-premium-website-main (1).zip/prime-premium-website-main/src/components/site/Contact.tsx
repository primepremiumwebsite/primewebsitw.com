export function Contact() {
  return (
    <section id="contact" className="px-6 py-24">
      <div className="mx-auto max-w-4xl">
        <div className="overflow-hidden rounded-3xl border border-border/60 bg-card-gradient p-10 shadow-elegant md:p-14">
          <div className="text-center">
            <span className="text-xs font-semibold uppercase tracking-widest text-primary">Contact</span>
            <h2 className="mt-3 text-4xl font-bold md:text-5xl">Let's build something great</h2>
            <p className="mx-auto mt-3 max-w-lg text-muted-foreground">
              Tell us about your project. We'll reply within 24 hours.
            </p>
          </div>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              const form = e.currentTarget;
              const name = (form.elements.namedItem("name") as HTMLInputElement).value;
              const email = (form.elements.namedItem("email") as HTMLInputElement).value;
              const project = (form.elements.namedItem("project") as HTMLTextAreaElement).value;
              const text = `Hello! My name is ${name} (${email}).%0A%0A${project}`;
              window.open(`https://wa.me/212777837154?text=${encodeURIComponent(text).replace(/%2520/g, "%20")}`, "_blank");
            }}
            className="mx-auto mt-10 grid max-w-xl gap-4"
          >
            <div className="grid gap-4 sm:grid-cols-2">
              <input
                required
                name="name"
                placeholder="Your name"
                className="rounded-xl border border-border bg-background/60 px-4 py-3 text-sm outline-none transition-colors focus:border-primary"
              />
              <input
                required
                name="email"
                type="email"
                placeholder="Email"
                className="rounded-xl border border-border bg-background/60 px-4 py-3 text-sm outline-none transition-colors focus:border-primary"
              />
            </div>
            <textarea
              required
              name="project"
              rows={5}
              placeholder="Tell us about your project..."
              className="rounded-xl border border-border bg-background/60 px-4 py-3 text-sm outline-none transition-colors focus:border-primary"
            />
            <button
              type="submit"
              className="mt-2 rounded-full bg-gradient-to-r from-primary to-accent px-6 py-3 text-sm font-semibold text-primary-foreground shadow-glow transition-transform hover:scale-[1.02]"
            >
              Send via WhatsApp
            </button>
          </form>
        </div>

        <footer className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-border/60 pt-8 text-sm text-muted-foreground md:flex-row">
          <div>© 2026 Prime Premium Website. All rights reserved.</div>
          <div className="flex gap-6">
            <a
              href="https://wa.me/212777837154"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-foreground"
            >
              WhatsApp: 0777837154
            </a>
            <a
              href="https://instagram.com/primemaher"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-foreground"
            >
              Instagram: @primemaher
            </a>
          </div>
        </footer>
      </div>
    </section>
  );
}
