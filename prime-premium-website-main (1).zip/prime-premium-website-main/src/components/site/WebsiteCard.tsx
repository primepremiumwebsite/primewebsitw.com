import type { Website } from "@/data/websites";

export function WebsiteCard({ site }: { site: Website }) {
  return (
    <article className="group relative flex flex-col overflow-hidden rounded-3xl border border-border/60 bg-card-gradient shadow-elegant transition-all duration-500 hover:-translate-y-1 hover:border-primary/40">
      <div className="relative aspect-[16/10] overflow-hidden bg-muted">
        <img
          src={site.image}
          alt={site.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-card via-card/20 to-transparent opacity-80" />
        <span className="absolute left-4 top-4 rounded-full border border-border/60 bg-background/70 px-3 py-1 text-xs font-medium backdrop-blur">
          {site.category}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-4 p-6">
        <div>
          <h3 className="font-display text-2xl font-bold">{site.title}</h3>
          <p className="mt-2 text-sm text-muted-foreground">{site.description}</p>
        </div>

        <div className="flex flex-wrap gap-2">
          {site.tags.map((t) => (
            <span key={t} className="rounded-full border border-border/60 bg-background/40 px-2.5 py-0.5 text-xs text-muted-foreground">
              {t}
            </span>
          ))}
        </div>

        <div className="mt-auto flex items-end justify-between border-t border-border/60 pt-5">
          <div>
            <div className="text-xs uppercase tracking-wider text-muted-foreground">Price</div>
            <div className="font-display text-3xl font-bold text-gradient-gold">€{site.price}+</div>
          </div>
          <a
            href="#contact"
            className="rounded-full bg-foreground px-5 py-2.5 text-sm font-semibold text-background transition-transform hover:scale-105"
          >
            Buy now
          </a>
        </div>
      </div>
    </article>
  );
}
