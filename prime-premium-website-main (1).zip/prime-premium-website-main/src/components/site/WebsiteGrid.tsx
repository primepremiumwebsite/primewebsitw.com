import { websites } from "@/data/websites";
import { WebsiteCard } from "./WebsiteCard";

export function WebsiteGrid() {
  return (
    <section id="websites" className="px-6 py-24">
      <div className="mx-auto max-w-7xl">
        <div className="mb-14 flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
          <div>
            <span className="text-xs font-semibold uppercase tracking-widest text-primary">Marketplace</span>
            <h2 className="mt-3 text-4xl font-bold md:text-5xl">Featured websites</h2>
            <p className="mt-3 max-w-xl text-muted-foreground">
              Hand-crafted templates ready to deploy. Each one is fully responsive,
              SEO-friendly and easy to customize.
            </p>
          </div>
          <a href="#contact" className="text-sm text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
            Don't see what you need? →
          </a>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {websites.map((site) => (
            <WebsiteCard key={site.id} site={site} />
          ))}
        </div>
      </div>
    </section>
  );
}
